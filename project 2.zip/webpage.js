document.addEventListener('DOMContentLoaded', function () {

    const loginButton = document.getElementById('loginBtn');
    
    if (loginButton) {
        loginButton.addEventListener('click', function () {
            alert('Redirecting to the login page...');
            window.location.href = 'login.html';
        });
    }
});
