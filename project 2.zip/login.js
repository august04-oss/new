document.addEventListener('DOMContentLoaded', function() {

    const form = document.getElementById('loginForm');
    const emailInput = form.querySelector('input[name="email"]');
    const passwordInput = form.querySelector('input[name="password"]');

    form.addEventListener('submit', function(event) {
        event.preventDefault();

        if (validateForm(emailInput.value, passwordInput.value)) {
            alert("Login successful!");
        } else {
        
            alert("Please enter both email and password.");
        }
    });

 
    function validateForm(email, password) {
        if (email === "" || password === "") {
            return false; 
        }
        const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
        if (!emailPattern.test(email)) {
            alert("Please enter a valid email address.");
            return false;
        }
        if (password.length < 6) {
            alert("Password must be at least 6 characters long.");
            return false; 
        }

        return true;
    }

});
