document.addEventListener('DOMContentLoaded', function() {

    const form = document.getElementById('signupForm');
    const nameInput = form.querySelector('input[name="name"]');
    const emailInput = form.querySelector('input[name="email"]');
    const passwordInput = form.querySelector('input[name="password"]');
    const confirmPasswordInput = form.querySelector('input[name="confirm_password"]');

    form.addEventListener('submit', function(event) {
        event.preventDefault();


        if (validateForm()) {
            alert('Sign-up successful!');
        }
    });

    function validateForm() {
        let valid = true;

        if (nameInput.value.trim() === '') {
            alert('Please enter your full name.');
            valid = false;
        }
        if (emailInput.value.trim() === '') {
            alert('Please enter your email address.');
            valid = false;
        } else {
            const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
            if (!emailPattern.test(emailInput.value)) {
                alert('Please enter a valid email address.');
                valid = false;
            }
        }

        if (passwordInput.value.trim() === '') {
            alert('Please enter a password.');
            valid = false;
        } else if (passwordInput.value !== confirmPasswordInput.value) {
            alert('Passwords do not match.');
            valid = false;
        }
        if (passwordInput.value.length < 6) {
            alert('Password must be at least 6 characters long.');
            valid = false;
        }

        return valid;
    }

});
